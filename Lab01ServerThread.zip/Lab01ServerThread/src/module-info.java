/**
 * 
 */
/**
 * 
 */
module Lab01ServerThread {
	requires java.desktop;
}