/**
 * 
 */
/**
 * 
 */
module Lab01 {
}